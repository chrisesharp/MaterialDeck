/**
 * This is a template for adding a new gaming system.
 * Edit it to suit your system, for inspiration, look at other system files.
 * Functions that are unused in your system can be left empty, but don't delete the function.
 * 
 * Use the compatibleCore function to get the right value for the Foundry core:
 * return compatibleCore('10.0') ? [value in v10+] : [value pre v10];
 * 
 * Use the compatibleSystem function to get the right value for the gaming system version:
 * return compatibleSystem('1.6.3') ? [value in v1.6.3+] : [value pre v1.6.3];
 */

import { compatibleCore } from "../misc.js";

/**
 * Proficiency colors to show if a token is proficient in for example a skill
 */
const proficiencyColors = {
    0: "#000000",
    0.5: "#804A00",
    1: "#C0C0C0",
    2: "#FFD700"
}

//Rename 'template' to the name of your system
export class helveczia {
    constructor(){
        console.log("Material Deck: Using system 'Helvéczia'");
    }

    getActorData(token) {
        return compatibleCore('10.0') ? token.actor.system : token.actor.data.data;
    }

    getItemData(item) {
        return compatibleCore('10.0') ? item.system : item.data.data;
    }

    /**
     * Returns the HP of the token
     * @param {Token} token Token instance to get the HP from
     * @returns {object}    Token hp value and max: {value: ##, max: ##}
     */
    
    getHP(token) {
        const hp = this.getActorData(token).hp;
        return {
            value: hp.value,
            max: hp.max
        }
    }

    /**
     * Returns the temporary HP of the token
     * @param {Token} token Token instance to get the temp HP from
     * @returns {object}    Token temp hp value and max: {value: ##, max: ##}
     */
    getTempHP(token) {
        // TODO
        return;
    }

    /**
     * Returns the armor class of the token
     * @param {Token} token Token instance to get the AC from
     * @returns {number}    AC value
     */
    getAC(token) {
        return this.getActorData(token).ac;
    }

    /**
     * Returns the shield HP of the token
     * @param {Token} token Token instance to get the shield HP from
     * @returns {number}    Shield HP
     */
    getShieldHP(token) {
        return;
    }

    /**
     * Returns a string with movement speeds of the token
     * @param {Token} token Token instance to get the speed from
     * @returns {string}    Movement speed string
     */
    getSpeed(token) {
        return;
    }

    /**
     * Returns the initiative of the token
     * @param {Token} token Token instance to get the initiative from
     * @returns {number}    Initiative value
     */
    
    getInitiative(token) {
        let initiative = this.getActorData(token).initiative;
        return (initiative >= 0) ? `+${initiative}` : initiative;
    }

    /**
     * Toggles the initiative of the token
     * @param {Token} token Token instance to toggle the initiative for
     */
    toggleInitiative(token) {
        return;
    }

    /**
     * Returns the passive perception of the token
     * @param {Token} token Token instance to get the passive perception from
     * @returns {number}    Passive perception value
     */
    getPassivePerception(token) {
        return;
    }

    /**
     * Returns the passive investigation of the token
     * @param {Token} token Token instance to get the passive investigation from
     * @returns {number}    Passive investigation value
     */
    getPassiveInvestigation(token) {
        return;
    }

    /**
     * Returns the ability value of the token
     * @param {Token} token     Token instance to get the ability value from
     * @param {string} ability  Ability to get the value from
     * @returns {number}        Ability value
     */

    getAbility(token, ability) {
        if (ability == undefined) ability = 'str';
        return this.getActorData(token).scores?.[ability].value;
    } 

    /**
     * Returns the ability modifier of the token
     * @param {Token} token     Token instance to get the ability modifier from
     * @param {string} ability  Ability to get the value from
     * @returns {number}        Ability modifier
     */
    
    getAbilityModifier(token, ability) {
        if (ability == undefined) ability = 'str';
        let val = this.getActorData(token).scores?.[ability].mod;
        return (val >= 0) ? `+${val}` : val;
    }

    /**
     * Returns the ability save of the token
     * @param {Token} token     Token instance to get the ability save from
     * @param {string} ability  Ability to get the value from
     * @returns {number}        Ability save
     */
    
    getAbilitySave(token, ability) {
        if (ability == undefined) ability = 'bravery';
        let val = this.getActorData(token).saves?.[ability].mod;
        return (val >= 0) ? `+${val}` : val;
    }

    /**
     * Returns the skill value of the token
     * @param {Token} token     Token instance to get the skill value from
     * @param {string} skill    Skill to get the value from
     * @returns {number}        Skill value
     */
    
    getSkill(token, skill) {
        if (skill == undefined) return;
        const skills = this.getActorData(token).skills?.find((i) => i.name === skill);
        let val = '0';
        if (skills instanceof array && skills?.length > 0 ){
            val = token.actor.getItemRollMod(skills[0]._id);
        }
        return val;
    }

    /**
     * Returns the proficiency value of the token
     * @param {Token} token Token instance to get the proficiency from
     * @returns {number}    Proficiency value
     */
    getProficiency(token) {
        return;
    }

    /**
     * Returns the icon location of a condition
     * @param {string} condition    Name of the condition
     * @returns {string}            Icon location
     */
    
    getConditionIcon(condition) {
        if (condition == undefined) condition = 'removeAll';
        if (condition == 'removeAll') return window.CONFIG.controlIcons.effects;
        else return CONFIG.statusEffects.find(e => e.id === condition).icon;
    }

    /**
     * Returns whether a condition is active on the token
     * @param {Token} token         Token instance to get the value from
     * @param {string} condition    Name of the condition
     * @returns {boolean}           Condition is active or not
     */
    
    getConditionActive(token,condition) {
        if (condition == undefined) condition = 'removeAll';
        return token.actor.effects.find(e => e.isTemporary === condition) != undefined;
    }

    /**
     * Toggles a condition on a token
     * @param {Token} token         Token instance to get the value from
     * @param {string} condition    Name of the condition
     */
    
    async toggleCondition(token,condition) {
        if (condition == undefined) condition = 'removeAll';
        if (condition == 'removeAll'){
            for( let effect of token.actor.effects)
                await effect.delete();
        }
        else {
            const effect = CONFIG.statusEffects.find(e => e.id === condition);
            await token.toggleEffect(effect);
        }
        return true;
    }

    /**
     * Roll for a token
     * @param {Token} token         Token instance to roll for
     * @param {string} roll         Roll type (ability/save/skill/initiative/deathSave)
     * @param {bbject} options      Roll options
     * @param {string} ability      Name of the ability to roll
     * @param {string} skill        Name of the skill to roll
     * @param {string} save         Name of the save to roll
     */

    async roll(token, roll, options, ability, skill, save) {
        if (roll == undefined) roll = 'ability';
        if (ability == undefined) ability = 'str';
        if (skill == undefined) skill = '';
        if (save == undefined) save = 'bravery';

        const dataset = {};
        switch (roll) {
            case 'ability':
                dataset.roll = 'attr';
                dataset.attr = ability;
                break;
            case 'save':
                dataset.roll = 'save';
                dataset.attr = save;
                break;
            case 'item':
                switch (token.type) {
                    default:
                        dataset.roll = 'weapon';
                        dataset.itemId = token._id;
                }
            case 'cc':
                dataset.roll = 'attack';
                dataset.attr = 'cc'
            default:
                break;
        }
        
        token.actor.sheet._onRoll({currentTarget: {dataset: dataset}, preventDefault: () => {}});
    }

    /**
     * Get array of items
     * @param {Token} token     Token instance to get the items from
     * @param {string} itemType Item type
     * @returns {array}         Array of items
     */
    getItems(token,itemType) {
        if (itemType == undefined) itemType = 'any';
        if (itemType === 'any') {
            return token.actor.items.filter(i => i.type == 'weapon' || i.type == 'armour' || i.type == 'possession' || i.type == 'book');
        }
        return token.actor.items.filter(i => i.type == itemType); 
    }

    /**
     * Returns uses/quantity of an item
     * @param {Item} item       Item instance to get the uses/quantity from
     * @returns {object}        Uses/quantity available {available: ###, maximum: ###}
     */
    getItemUses(item) {
        return;
    }

    /**
     * Returns the features of a token
     * @param {Token} token         Token instance to get the features from
     * @param {string} featureType  Feature types to return
     * @returns {array}             Array of features
     */
    getFeatures(token,featureType) {
        if (featureType == undefined) featureType = 'any';
        if (featureType == 'any')                   return;
        else                                        return;
    }

    /**
     * Returns uses/quantity of a feature
     * @param {Item} item       Item/feature instance to get the uses/quantity from
     * @returns {object}        Uses/quantity available {available: ###, maximum: ###}
     */
    getFeatureUses(item) {
        return {};
    }

    /**
     * Returns the spells of a token
     * @param {Token} token     Token instance to get the spells from
     * @param {string} level    Spell level
     * @returns {array}         Array of spells
     */
    getSpells(token,level) {
        if (level == undefined) level = 0;
        const allSpells = this.getActorData(token).spells;
        return allSpells[Math.min(Math.max(level - 1, 0),2)];
    }

    /**
     * Returns the spell uses of a specific spell for a token
     * @param {Token} token     Token instance to get the spell uses from
     * @param {string} level    Spell level
     * @param {Item} item       Spell instance to get the uses from
     * @returns {object}        Spell uses left: {available: ###, maximum: ###}
     */
    getSpellUses(token,level,item) {
        return {
        }
    }

    /**
     * Roll an item
     * @param {Token} item          Item instance to roll
     * @param {object} settings     Settings of the action
     * @param {object} rollOption   Roll options
     */
    rollItem(item, settings, rollOption) {
        return this.roll(item, 'item', rollOption, settings);
    }

    /**
     * Returns a color to display proficiency for skills
     * @param {Token} token     Token instance to get the proficiency from
     * @param {string} skill    Skill name
     * @returns {string}        Hex color string from proficiencyColors array
     */

    getSkillRingColor(token, skill) {
        return;
    }

    getSaveRingColor(token, save) {
        return;        
    }

    getVirtue(token) {
        return this.getActorData(token).virtue;
    }
}